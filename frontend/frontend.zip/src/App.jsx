import Hero from "./components/Hero";
import DepositCard from "./components/DepositCard";
import ProofCard from "./components/ProofCard";
import StatusTimeline from "./components/StatusTimeline";
import WithdrawCard from "./components/WithdrawCard";
import Footer from "./components/Footer";

export default function App() {
  return (
    <main
      style={{
        background: "#050505",
        color: "white",
        minHeight: "100vh",
      }}
    >
      <Hero />
      <DepositCard />
      <ProofCard />
      <StatusTimeline />
      <WithdrawCard />
      <Footer />
    </main>
  );
}